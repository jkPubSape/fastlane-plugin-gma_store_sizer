module Fastlane
  module GmaStoreSizer
    VERSION = "0.1.0"
  end
end
